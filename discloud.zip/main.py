import discord
from discord.ext import commands

TOKEN = 'MTA5Njc5NzA4MzE0NDU3Mjk1OQ.GOuE1T.BR39C_RAmPOlvOfhbEscKq0RYNKq5TZAbmjEPU'
CHANNELID = 1091438305574408192

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print("Bot is ready.")

async def send_event_embed(event, color, content):
    start_time = event.start_time.strftime("%Y-%m-%d %H:%M")
    channel = bot.get_channel(CHANNELID)
    embed = discord.Embed(title=event.name, description=event.description, color=color)
    embed.add_field(name="開始日時", value=start_time)
    embed.add_field(name="開催場所", value=event.location)
    embed.set_author(name=event.creator.global_name, icon_url=event.creator.avatar)
    await channel.send(content=content, embed=embed)

@bot.event
async def on_scheduled_event_create(event):
    await send_event_embed(event, 0x2196F3, "以下のイベントが作成されました🏁")

@bot.event
async def on_scheduled_event_update(before, after):
    await send_event_embed(after, 0x4CAF50, "以下のイベントが更新されました🔄")

bot.run(TOKEN)

# 参考URL
# https://docs.pycord.dev/en/stable/api/events.html#scheduled-events
# https://discord.com/developers/docs/resources/channel#embed-object
# https://discord.com/developers/docs/resources/user#users-resource
# https://docs.pycord.dev/en/stable/api/models.html#discord.ScheduledEvent